package inpt.sud.springbootbackend

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringbootbackendApplicationTests {

	@Test
	fun contextLoads() {
	}

}
